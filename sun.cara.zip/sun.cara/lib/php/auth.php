<?php

function MYSQLIAuth() {
	return [
		"localhost", // my sql host
		"carayiwei_aauwnm", // mysql user name
		"Sunyiwei0824!", //mysql user password
		"carayiwei_aauwnm608" //mysql database name
	];
}