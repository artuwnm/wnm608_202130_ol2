<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Earrings</title>

	

	<?php include "parts/meta.php"; ?>
</head>
<body>
	<?php include "parts/navbar.php"; ?>

	<div class="container">	
		<div class="card soft">
			<h2>Earrings</h2>




<div class="card">
<h3>Single Product Image</h3>

<div class="figure">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>Product</figcaption>
    </figure>

</div>