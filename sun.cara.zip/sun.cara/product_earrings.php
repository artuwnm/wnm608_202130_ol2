<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Earrings</title>

	

	<?php include "parts/meta.php"; ?>
</head>
<body>
	<?php include "parts/navbar.php"; ?>

	<div class="container">	
		<div class="card soft">
			<h2>Earrings</h2>

			 

   <div class="grid gap">
    	<div class=".col-xs-12. col-md-4">
    		<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<a href="product_earrings1.php">Click the Product</a>
		<div>$880</div>
	</figcaption>
    </figure>

    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>
    </div>





  

   <div class="grid gap">
    	<div class=".col-xs-12. col-md-4">
    		<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>

    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>
    </div>




   <div class="grid gap">
    	<div class=".col-xs-12. col-md-4">
    		<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>

    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>

    <div class=".col-xs-12. col-md-4">
    	<figure class="figure product">
	<img src="http://via.placeholder.com/400x400?text=product" alt="">
	<figcaption>
		<div>Product Name</div>
		<div>$880</div>
	</figcaption>
    </figure>
    		
    </div>
    </div>
</div>